import numpy as np
import pandas as pd
import xgboost as xgb
from alibi.explainers import AnchorText
from alibi.explainers import PartialDependenceVariance
from alibi.explainers import TreeShap
from alibi.explainers import KernelShap
from alibi.explainers import AnchorTabular
from alibi.explainers.shap_wrappers import sum_categories
from alibi.utils import gen_category_map
from scipy.special import expit
from sklearn import preprocessing
from sklearn.impute import SimpleImputer
from explain.config.logger import CustomLogger
from sklearn.model_selection import train_test_split
from enum import Enum

log = CustomLogger()


class ResponsibleAIExplain:

    def local_explain_tabular(dataset,
                       inputIndex,
                       model,
                       preprocessor,
                       featureNames,
                       categoricalFeatureNames,
                       targetNames):

        try:

            predict_fn = lambda x: model.predict(preprocessor.transform(x))
            category_map = gen_category_map(dataset,categorical_columns=categoricalFeatureNames)

            label_encoder = preprocessing.LabelEncoder()
            target = label_encoder.fit_transform(dataset[targetNames])
            targetClass = dataset[targetNames].unique()
            X = dataset.drop(targetNames, axis=1, inplace=False)
            column_names = list(X.columns.values)

            label_encoder = preprocessing.LabelEncoder()
            for col in column_names:
                X[col] = label_encoder.fit_transform(X[col])

            imputer = SimpleImputer(missing_values=np.nan, strategy='mean')
            imputer = imputer.fit(X)
            data = imputer.transform(X)

            data_perm = np.random.permutation(np.c_[data, target])
            data = data_perm[:, :-1]
            target = data_perm[:, -1]

            X_train, X_test, y_train, y_test = train_test_split(data, target, test_size=0.20, train_size=0.80,
                                                                random_state=0)
            explainer = AnchorTabular(
                predictor=predict_fn,
                feature_names=featureNames,
                categorical_names=category_map)

            explainer.fit(X_train, disc_perc=[25, 50, 75])
            explaination = explainer.explain(X_test[inputIndex], threshold=0.95)
            prediction = targetClass[explainer.predictor(X_test[inputIndex].reshape(1, -1))[0]]

            return {"predictedTarget": prediction, "anchor": explaination.anchor}

        except Exception as e:
            log.error(e, exc_info=True)
            return {"predictedTarget": "", "anchor": ""}


    def local_explain(text: str,model,vectorizer, class_names):

        log.info("Running local_explain")

        try:

            predict_fn = lambda x: model.predict(vectorizer.transform(x))
            prediction = class_names[predict_fn([text])[0]]
            explainer = AnchorText.load('../models//alibi//', predictor=predict_fn)
            explaination = explainer.explain(text,
                                             threshold=0.95,
                                             stop_on_first=True,
                                             min_samples_start=100,
                                             coverage_samples=100,
                                             )
            return {"predictedTarget": prediction, "anchor": explaination.anchor}

        except Exception as e:
            log.error(e,exc_info=True)
            return {"predictedTarget": prediction, "anchor": explaination.anchor}

    def global_explain(dataset,
                       method,
                       model,
                       preprocessor,
                       featureNames,
                       categoricalFeatureNames,
                       targetNames):

        try:

            params = {
                "dataset":dataset,"model":model,
                "preprocessor":preprocessor,
                "featureNames": featureNames,
                "categoricalFeatureNames":categoricalFeatureNames,
                "targetNames":targetNames}

            method = str(method).lower()

            # log.debug(f"params: {params}")
            if method == "pd-variance":
                return ResponsibleAIExplain.partial_dependence_variance(params)
            elif method == "kernel-shap":
                return ResponsibleAIExplain.kernel_shap(params)
            elif method == "tree-shap":
                return ResponsibleAIExplain.tree_shap(params)

            return [{"importantFeatures":[{"featureName": "", "importanceScore": ""}]}]

        except Exception as e:
            log.error(e,exc_info=True)
            return [{"importantFeatures":[{"featureName": "", "importanceScore": ""}]}]


    def partial_dependence_variance(params: dict):

        try:
            dataset = params['dataset']
            targetNames = params['targetNames']
            model = params['model']
            featureNames = params["featureNames"]
            categoricalFeatureNames = params["categoricalFeatureNames"]
            targetClass = dataset[targetNames].unique()
            X = dataset.drop(targetNames, axis=1, inplace=False)
            column_names = list(X.columns.values)

            label_encoder = preprocessing.LabelEncoder()
            for col in column_names:
                X[col] = label_encoder.fit_transform(X[col])

            imputer = SimpleImputer(missing_values=np.nan, strategy='mean')
            imputer = imputer.fit(X)
            X = imputer.transform(X)

            pd_variance = PartialDependenceVariance(predictor=model
                                                    ,target_names=targetClass
                                                    ,categorical_names=categoricalFeatureNames
                                                    ,feature_names=featureNames)
            exp_importance = pd_variance.explain(X=X,
                                                 method='importance'
                                                 )
            log.debug(f"exp_importance: {exp_importance}")
            data = dict(zip(column_names, exp_importance.feature_importance[0]))
            log.debug(f"data: {data}")
            sorted_data = dict(sorted(data.items(), key = lambda x: x[1], reverse = True))
            log.debug(f"sorted_data: {sorted_data}")

            list_data = []
            features_count = 1
            for k, v in sorted_data.items():
                if features_count <= 5:
                    list_data.append({"featureName": k, "importanceScore": v})
                features_count = features_count + 1

            return [{"className":targetClass[0],"importantFeatures":list_data}]

        except Exception as e:
            log.error(e,exc_info=True)
            raise Exception

    def get_kernel_shap_importance(class_idx, beta, feature_names, intercepts=None):
        """
        Retrive and sort abs magnitude of coefficients from model.
        """

        # sort the absolute value of model coef from largest to smallest

        try:
            srt_beta_k = np.argsort(np.abs(beta[class_idx, :]))[::-1]
            feat_names = [feature_names[idx] for idx in srt_beta_k]
            feat_imp = beta[class_idx, srt_beta_k]
            # include bias among feat importances
            if intercepts is not None:
                intercept = intercepts[class_idx]
                bias_idx = len(feat_imp) - np.searchsorted(np.abs(feat_imp)[::-1], np.abs(intercept))
                feat_imp = np.insert(feat_imp, bias_idx, intercept.item(), )
                intercept_idx = np.where(feat_imp == intercept)[0][0]
                feat_names.insert(intercept_idx, 'bias')

            return feat_imp, feat_names
        except Exception as e:
            log.error(e, exc_info=True)
            raise  Exception

    def kernel_shap(params: dict):

        try:

            featureNames = params["featureNames"]
            categoricalFeatureNames = params["categoricalFeatureNames"]
            classifier = params['model']
            preprocessor = params['preprocessor']
            dataset = params['dataset']
            targetNames = params['targetNames']
            targetClass = dataset[targetNames].unique()
            log.debug(f"targetClass: {targetClass}")
            category_map = gen_category_map(data=dataset,categorical_columns=categoricalFeatureNames)
            ordinal_features = [x for x in range(len(featureNames)) if x not in list(category_map.keys())]
            categorical_features = list(category_map.keys())
            fts = [featureNames[x] for x in categorical_features]
            ohe = preprocessor.transformers_[1][1].named_steps['onehot']
            cat_enc_feat_names = ohe.get_feature_names_out(fts)
            feat_enc_dim = [len(cat_enc) - 1 for cat_enc in ohe.categories_]
            d = {'feature_names': fts, 'encoded_dim': feat_enc_dim}
            df = pd.DataFrame(data=d)
            total_dim = df['encoded_dim'].sum()
            assert total_dim == len(cat_enc_feat_names)
            numerical_feats_idx = preprocessor.transformers_[0][2]
            categorical_feats_idx = preprocessor.transformers_[1][2]
            scaler = preprocessor.transformers_[0][1].named_steps['scaler']
            num_feats_names = [featureNames[i] for i in numerical_feats_idx]
            cat_feats_names = [featureNames[i] for i in categorical_feats_idx]
            start = len(ordinal_features)
            cat_feat_start = [start]
            for dim in feat_enc_dim[:-1]:
                cat_feat_start.append(dim + cat_feat_start[-1])
            beta = classifier.coef_
            beta = np.concatenate((-beta, beta), axis=0)
            intercepts = classifier.intercept_
            intercepts = np.concatenate((-intercepts, intercepts), axis=0)
            all_coef = sum_categories(beta, cat_feat_start, feat_enc_dim)

            list_kernel_shap= []

            for class_idx in range(0,len(targetClass)):

                perm_feat_names = num_feats_names + cat_feats_names

                feat_imp, srt_feat_names = ResponsibleAIExplain.get_kernel_shap_importance(class_idx,
                                                          all_coef,
                                                          perm_feat_names,
                                                          )

                data = dict(zip(srt_feat_names, feat_imp))
                log.debug(f"data: {data}")
                sorted_data = dict(sorted(data.items(), key=lambda x: x[1], reverse=True))
                log.debug(f"sorted_data: {sorted_data}")

                list_data = []
                features_count = 1
                for k, v in sorted_data.items():
                    if features_count <= 5:
                        list_data.append({"featureName": k, "importanceScore": v})
                    features_count = features_count + 1


                list_kernel_shap.append({"className":targetClass[class_idx],
                      "importantFeatures":list_data})

            return list_kernel_shap

        except Exception as e:
            log.error(e, exc_info=True)
            raise Exception

    def tree_shap(params: dict):
        try:
            featureNames = params["featureNames"]
            categoricalFeatureNames = params["categoricalFeatureNames"]
            model = params['model']
            dataset = params['dataset']
            targetNames = params['targetNames']
            targetClass = dataset[targetNames].unique()
            log.debug(f"targetClass: {targetClass}")
            category_map = gen_category_map(data=dataset, categorical_columns=categoricalFeatureNames)
            tree_shap_explainer = TreeShap(
                model,
                feature_names=featureNames,
                categorical_names=category_map
            )
            tree_shap_explainer.fit()

            X = dataset.drop(targetNames, axis=1, inplace=False)
            column_names = list(X.columns.values)

            label_encoder = preprocessing.LabelEncoder()
            for col in column_names:
                X[col] = label_encoder.fit_transform(X[col])

            imputer = SimpleImputer(missing_values=np.nan, strategy='mean')
            imputer = imputer.fit(X)
            X = imputer.transform(X)
            explanation = tree_shap_explainer.explain(X)
            importances = explanation['data']['raw']['importances']
            targetClass = dataset[targetNames].unique()
            log.debug(f"targetClass: {targetClass}")
            class_idx = 0

            list_tree_shap = []
            for item in importances.items():

                if item[0] == 'aggregated':
                    break
                data = dict(zip(item[1]['names'], item[1]['ranked_effect']))
                sorted_data = dict(sorted(data.items(), key=lambda x: x[1], reverse=True))

                features_count = 1
                list_importance = []
                for k, v in sorted_data.items():
                    if features_count > 5:
                        break
                    list_importance.append({"featureName": k, "importanceScore": v})
                    features_count = features_count + 1
                list_tree_shap.append({"className":targetClass[class_idx],
                                        "importantFeatures": list_importance})
                class_idx = class_idx + 1
            log.debug(f"list_importance: {list_importance}")
            return list_tree_shap

        except Exception as e:
            log.error(e, exc_info=True)
            raise Exception
