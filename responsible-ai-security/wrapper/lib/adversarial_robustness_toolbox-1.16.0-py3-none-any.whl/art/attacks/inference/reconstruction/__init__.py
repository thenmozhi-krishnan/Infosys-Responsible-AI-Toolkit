"""
Module providing model inversion attacks.
"""
from art.attacks.inference.reconstruction.white_box import DatabaseReconstruction
