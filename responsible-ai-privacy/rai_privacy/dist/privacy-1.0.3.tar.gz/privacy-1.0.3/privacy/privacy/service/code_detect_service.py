'''
© <2023> Infosys Limited, Bangalore, India. All Rights Reserved.
 Version: 
Except for any free or open source software components embedded in this Infosys proprietary software program (“Program”), this Program is protected by copyright laws, international treaties and other pending or existing intellectual property rights in India, the United States and other countries. Except as expressly permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will be prosecuted to the maximum extent possible under the law.
'''


import base64
import json
import io, base64
from PIL import Image
import requests
import pandas as pd
from privacy.mappers.mappers import *
import os

from privacy.config.logger import CustomLogger
from privacy.util.code_detect import *
from privacy.util.code_detect.regexdetection import *
import json
from privacy.util.code_detect.ner.pii_inference.netcustom import code_detect_ner
log = CustomLogger()

class AttributeDict(dict):
    __getattr__ = dict.__getitem__
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__


class CodeDetect:
    def codeDetectRegex(payload)->PIICodeDetectRequest:
        payload=AttributeDict(payload)
        print("Text===",payload)
        #finalpayload=str(payload)
        #ouputjson=json.loads(payload)
        output_code=code_detect.codeDetectRegex(payload.inputText)
        print("output_code===",output_code)
        return output_code
    
    def codeDetectNerText(payload)->PIICodeDetectRequest:
        payload=AttributeDict(payload)
        print("Text===",payload)
        #finalpayload=str(payload)
        #ouputjson=json.loads(payload)
        output_code=code_detect_ner.textner(payload.inputText)
        print("output_code===",output_code)
        return output_code  
