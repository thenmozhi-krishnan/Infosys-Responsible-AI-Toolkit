'''
© <2023> Infosys Limited, Bangalore, India. All Rights Reserved.
 Version: 
Except for any free or open source software components embedded in this Infosys proprietary software program (“Program”), this Program is protected by copyright laws, international treaties and other pending or existing intellectual property rights in India, the United States and other countries. Except as expressly permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will be prosecuted to the maximum extent possible under the law.
'''
import pymongo
import datetime,time
from privacy.dao.DatabaseConnection import DB
from dotenv import load_dotenv
from privacy.config.logger import CustomLogger

load_dotenv()
log = CustomLogger()

class AttributeDict(dict):
    __getattr__ = dict.__getitem__
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__


mydb=DB.connect()


class AccDataGrpDb:
    mycol = mydb["AccDataGrp"]
    def findOne(id):
        values=AccDataGrpDb.mycol.find({"_id":id},{})[0]
        # print(values)
        values=AttributeDict(values)
        return values
    def findall(query):
        value_list=[]
        values=AccDataGrpDb.mycol.find(query,{})
        for v in values:

            v=AttributeDict(v)
            value_list.append(v)
        return value_list
    def create(value):
         value=AttributeDict(value)
         localTime = time.time()
         mydoc = {
        "_id":localTime,
        "accMasterId":value.Aid,
        "dataRecogGrpId":value.Did,
        "isActive":"Y",
        "isHashify":False,
        "isCreated":"Not Started",
        "CreatedDateTime": datetime.datetime.now(),
        "LastUpdatedDateTime": datetime.datetime.now(),
         }
         PtrnRecogCreatedData = AccDataGrpDb.mycol.insert_one(mydoc)
         return PtrnRecogCreatedData.acknowledged
    
    def update(query,value:dict):
        
        newvalues = { "$set": value }
        
        PtrnRecogUpdatedData=AccDataGrpDb.mycol.update_one(query,newvalues)
        log.debug(str(newvalues)) 
        return PtrnRecogUpdatedData.acknowledged
    
    def delete(id):
        return AccDataGrpDb.mycol.delete_many({"dataRecogGrpId":id}).acknowledged
        # DocProcDtl.mycol.delete_many({})
        # Docpagedtl.mycol.delete_many({})
    def deleteMany(query):
        return AccDataGrpDb.mycol.delete_many(query).acknowledged
    
    