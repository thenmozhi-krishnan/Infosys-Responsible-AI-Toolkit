'''
© <2023> Infosys Limited, Bangalore, India. All Rights Reserved.
 Version: 
Except for any free or open source software components embedded in this Infosys proprietary software program (“Program”), this Program is protected by copyright laws, international treaties and other pending or existing intellectual property rights in India, the United States and other countries. Except as expressly permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will be prosecuted to the maximum extent possible under the law.
'''
class PrivacyTelemetryRequest:
    def __init__(self, tenant, apiname, date,user,beginOffset,endOffset,score,responseText,restype, portfolio=None, accountname=None, exclusion_list=None, entityrecognised=None,inputText=None):
        self.tenant = tenant
        self.apiname = apiname
        self.date = date
        self.user = user
        self.privacy_requests = {
            'portfolio_name': str(portfolio) if portfolio is not None else "None",
            'account_name': str(accountname) if accountname is not None else "None",
            'exclusion_list': exclusion_list.split(',') if exclusion_list is not None else [],
            'inputText': str(inputText) if inputText is not None else "None",
        }
        self.privacy_response = {
            'type': str(restype) if restype is not None else "None",
            'beginOffset': float(beginOffset) if beginOffset is not None else 0,
            'endOffset': float(endOffset) if endOffset is not None else 0,
            'score': float(score) if score is not None else "None",
            'responseText': str(responseText) if responseText is not None else "None",

        }