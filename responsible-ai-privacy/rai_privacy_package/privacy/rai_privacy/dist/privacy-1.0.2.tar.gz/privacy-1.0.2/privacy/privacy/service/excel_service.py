'''
© <2023> Infosys Limited, Bangalore, India. All Rights Reserved.
 Version: 
Except for any free or open source software components embedded in this Infosys proprietary software program (“Program”), this Program is protected by copyright laws, international treaties and other pending or existing intellectual property rights in India, the United States and other countries. Except as expressly permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will be prosecuted to the maximum extent possible under the law.
'''

import base64
import json
import io, base64
from PIL import Image
import requests
import pandas as pd
from privacy.mappers.mappers import *
from privacy.service.service import *
import os
import openpyxl
from openpyxl.reader.excel import load_workbook
import xlsxwriter

from privacy.config.logger import CustomLogger

log = CustomLogger()

class AttributeDict(dict):
    __getattr__ = dict.__getitem__
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__

import shutil
class Excel:

    def excelanonymize(payload):
        
        payload=AttributeDict(payload)
        # print("paload29====",payload)
        # dataframe1 = pd.read_excel(payload.excel.file.read())
        # print("data==",dataframe1)
        # df = pd.DataFrame(dataframe1)
        with open("x.xlsx","wb") as f:
            shutil.copyfileobj(payload.excel.file,f)
        wrkbk = openpyxl.load_workbook("x.xlsx")
        sh = wrkbk.active
        # sh=wrkbk.get_sheet_by_name("Sheet1")

        # print("sh====",sh)
        # format = sh.get
        

        # print("type====",df)
        x=""
        s=""
        row=0
        col=0
        path= "ExcelOutput.xlsx"
        workbook = xlsxwriter.Workbook(path)
        worksheet = workbook.add_worksheet()
        # worksheet.set_format(format)
        r=0
        list=[]
        i=0

        
        for row in sh.iter_rows(min_row = 1,min_col=1):
            
                 
            # print("row===",row)

            for cell in row:
                cell_coor=cell.coordinate
                print("cell",cell.coordinate)
                print("cell_value=====",cell.value)
               
                # s+=str(cell.value) + " ;* "
                #  for cell in row:
               
                # s+=str(cell.value) + " ;* "
                # print(cell.value,end=" / ")
            
            
                payload1={"inputText":str(cell.value),"exclusionList":None,"portfolio":"Infosys_Help","account":"HelpDesk"}
                payload1=AttributeDict(payload1)
                

                temp = PrivacyService.anonymize(payload1)
                print("response===",temp.anonymizedText)
                # print("row=======",row)
                # print("list===",list)

                print("Old cell value===",str(cell.value))
                sh[str(cell_coor)]=temp.anonymizedText
                print("New cell value===",str(cell.value))


                # print(cell.value,end=" / ")
            
            
            # payload1={"inputText":s,"exclusionList":None,"portfolio":None}
            # payload1=AttributeDict(payload1)
            

            # temp = PrivacyService.anonymize(payload1)
            # print("response===",temp.anonymizedText)
            # # print("row=======",row)
            # print("list===",list)


            # # Excel.createExcel(temp.anonymizedText,x,r,0,worksheet)
            # Excel.createExcel(temp.anonymizedText,x,r,0,worksheet)

            # r+=1

            # s=""


        
 
       
        wrkbk.save(filename="x.xlsx")
        print("temp====",s)
        print("x=====",x)
        # sh = wrkbk.active
        # s = ""
        # for row in sh.iter_rows(min_row = 2,min_col=1):
        #     for cell in row:
        #         s+=str(cell.value) + " ;* "
        #         # print(cell.value,end=" / ")

        #     s+="\n"
        #     # print()
        # # print(s)

        # payload1={"inputText":s,"exclusionList":None,"portfolio":None}
        # payload1=AttributeDict(payload1)

        # temp = PrivacyService.anonymize(payload1)
        # print("response===",temp.anonymizedText)
        # return Excel.createExcel(temp.anonymizedText,x)
        print("Workbook==",workbook)
        # workbook.close()
        return "x.xlsx"



        # image = Image.open(payload.image.file)
        # print("image===",image)





    def createExcel(s,x,row,col,worksheet):
        # path= "ExcelOutput.xlsx"
        # workbook = xlsxwriter.Workbook(path)
        # worksheet = workbook.add_worksheet()

        # row = 0
        # col = 0

        # for val in x:
        #     worksheet.write(row,col,val)
        #     col+=1
        # row+=1
        # col=0
        print("row187===",row)

        for x in s.split(';*'):
                # print("x===",x)
                # worksheet.append(x)
                worksheet.write(row,col,x)
                col+=1

        
        
        # print("Workbook==",workbook)
        # workbook.close()

        # return path

