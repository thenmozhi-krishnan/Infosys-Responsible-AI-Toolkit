

from aif360.metrics import BinaryLabelDatasetMetric
from aif360.metrics import ClassificationMetric
from aif360.metrics.utils import compute_boolean_conditioning_vector
from aif360.datasets import StandardDataset
import pandas as pd


privileged_groups=[]
unprivileged_groups=[]

class AttributeDict(dict):
    __getattr__ = dict.__getitem__
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__

class ProtetedAttribute:
      def __init__(self,name,privileged,unprivileged):
            self.protetedAttribute={"name":name,"privileged": privileged,"unprivileged" :unprivileged}
            self.protetedAttribute=AttributeDict(self.protetedAttribute)

class BiasResults:
      def __init__(self,protectedcAttrib,metrics):
            self.biasResults={"protectedcAttrib":protectedcAttrib,"metrics":metrics}
            self.biasResults=AttributeDict(self.biasResults)

class metricsEntity:
      def __init__(self,name,description,value):
            self.metricsEntity={"name":name,"description":description,"value":value}
            self.metricsEntity=AttributeDict(self.metricsEntity)

      

class DataList:
      def getDataList(datasetPath,label,protectedAttributes,favourableOutcome,CategoricalAttributes,features,predlabel,biastype)->list:
              df = pd.read_csv(datasetPath)
              label_name = label
              protected_attribute = [protectedAttributes.name]
              privileged_groups.append({f'{protected_attribute[0]}' : 1.0 })
              unprivileged_groups.append({f'{protected_attribute[0]}' : 0.0 })
              
              dataset_orig = StandardDataset(df=df,label_name = label_name,favorable_classes =favourableOutcome,
                                        protected_attribute_names=protected_attribute,
                                        privileged_classes= [[protectedAttributes.privileged],[protectedAttributes.unprivileged]],
                                        instance_weights_name="",
                                        categorical_features= CategoricalAttributes,
                                        features_to_keep=features, features_to_drop=[predlabel],
                                        na_values=[], custom_preprocessing=None,
                                        metadata={} 
                                      )

              datalist=[dataset_orig]
              if(biastype=="POSTTRAIN" or biastype=="ALL"):
                    dataset_pred=dataset_orig.copy(deepcopy=True)
                    df_pred=df.drop([label_name],axis=1)

                    predicted_column_name = predlabel
                    data_prd = StandardDataset(df=df_pred,label_name = predicted_column_name,favorable_classes = favourableOutcome,
                                      protected_attribute_names=protected_attribute,
                                      privileged_classes= [[protectedAttributes.privileged],[protectedAttributes.unprivileged]],
                                      instance_weights_name=None,
                                      categorical_features= CategoricalAttributes,
                                      features_to_keep=[], features_to_drop=[label_name],
                                      na_values=[], custom_preprocessing=None,
                                      metadata={} 
                                     )
                    dataset_pred.labels=data_prd.labels
                    datalist.append(dataset_pred)
              return datalist

            
            
class BiasResult:
    def analyzeResult(biastype,methods,protectedAttributes,datalist):
        obj_protectAttrib = ProtetedAttribute(name = protectedAttributes.name,
                                          privileged = protectedAttributes.privileged,
                                          unprivileged = protectedAttributes.unprivileged)
        print(obj_protectAttrib.protetedAttribute)
        list_metric_results = []
        for i in range(len(methoddict[biastype][methods])):
          List_metric_score= methoddict[biastype][methods][i](datalist)
          list_metric_results.append(List_metric_score)
 
        bias_list=[]
        obj_biasresults = BiasResults(protectedcAttrib = obj_protectAttrib.protetedAttribute,
                                    metrics = list_metric_results)
        bias_list.append(obj_biasresults.biasResults)
        print(bias_list)
        return(bias_list)
        
        

class PRETRAIN:
   def STATISTICAL_PARITY_DIFFERENCE(datalist):
            metric_scaled = BinaryLabelDatasetMetric(datalist[0], 
                            unprivileged_groups=unprivileged_groups,
                            privileged_groups=privileged_groups)
            obj_metric_sp = metricsEntity(name='STATISTICAL PARITY-DIFFERENCE',
                                    description = 'Computed as the difference of the rate of favorable outcomes received by the unprivileged group to the privileged group.The ideal value of this metric is 0. Fairness for this metric is between -0.1 and 0.1',
                                  value=round(metric_scaled.statistical_parity_difference(),2))
            return obj_metric_sp.metricsEntity
   
   def DISPARATE_IMPACT(datalist):
            metric_scaled = BinaryLabelDatasetMetric(datalist[0], 
                            unprivileged_groups=unprivileged_groups,
                            privileged_groups=privileged_groups) 
            obj_metric_di = metricsEntity(name='DISPARATE-IMPACT',
                                    description = 'Computed as the ratio of rate of favorable outcome for the unprivileged group to that of the privileged group. The ideal value of this metric is 1.0 A value < 1 implies higher benefit for the privileged group and a value >1 implies a higher benefit for the unprivileged group. Fairness for this metric is between 0.8 and 1.25',
                                  value=round(metric_scaled.disparate_impact(),2))
            return obj_metric_di.metricsEntity

class POSTTRAIN:
   def STATISTICAL_PARITY_DIFFERENCE(datalist):
            metric_scaled = ClassificationMetric(datalist[0],datalist[1], 
                            unprivileged_groups=unprivileged_groups,
                            privileged_groups=privileged_groups)
            
            obj_metric_sp = metricsEntity(name='STATISTICAL PARITY-DIFFERENCE',
                                    description = 'Computed as the difference of the rate of favorable outcomes received by the unprivileged group to the privileged group.The ideal value of this metric is 0. Fairness for this metric is between -0.1 and 0.1',
                                  value=round(metric_scaled.statistical_parity_difference(),2))
            return obj_metric_sp.metricsEntity
   
   def DISPARATE_IMPACT(datalist):
            metric_scaled = ClassificationMetric(datalist[0],datalist[1], 
                            unprivileged_groups=unprivileged_groups,
                            privileged_groups=privileged_groups) 
            obj_metric_di = metricsEntity(name='DISPARATE-IMPACT',
                                    description = 'Computed as the ratio of rate of favorable outcome for the unprivileged group to that of the privileged group. The ideal value of this metric is 1.0 A value < 1 implies higher benefit for the privileged group and a value >1 implies a higher benefit for the unprivileged group. Fairness for this metric is between 0.8 and 1.25',
                                  value=round(metric_scaled.disparate_impact(),2))
            return obj_metric_di.metricsEntity

   def EQUAL_OPPORTUNITY_DIFFERENCE(datalist):
            metric_scaled = ClassificationMetric(datalist[0],datalist[1], 
                            unprivileged_groups=unprivileged_groups,
                            privileged_groups=privileged_groups)
            
            obj_metric_eod = metricsEntity(name='EQUAL-OPPORTUNITY-DIFFERENCE',
                                    description = 'Computed as the difference of the rate of favorable outcomes received by the unprivileged group to the privileged group.The ideal value of this metric is 0. Fairness for this metric is between -0.1 and 0.1',
                                  value=round(metric_scaled.equal_opportunity_difference(),2))
            return obj_metric_eod.metricsEntity
   
   def AVERAGE_ODDS_DIFFERENCE(datalist):
            metric_scaled = ClassificationMetric(datalist[0],datalist[1], 
                            unprivileged_groups=unprivileged_groups,
                            privileged_groups=privileged_groups) 
                            
            obj_metric_aod = metricsEntity(name='AVERAGE-ODDS-DIFFERENCE',
                                    description = 'Computed as the ratio of rate of favorable outcome for the unprivileged group to that of the privileged group. The ideal value of this metric is 1.0 A value < 1 implies higher benefit for the privileged group and a value >1 implies a higher benefit for the unprivileged group. Fairness for this metric is between 0.8 and 1.25',
                                  value=round(metric_scaled.average_odds_difference() ,2))
            return obj_metric_aod.metricsEntity

postlist=[POSTTRAIN.STATISTICAL_PARITY_DIFFERENCE,POSTTRAIN.EQUAL_OPPORTUNITY_DIFFERENCE,POSTTRAIN.AVERAGE_ODDS_DIFFERENCE,POSTTRAIN.DISPARATE_IMPACT]      
prelist=[PRETRAIN.STATISTICAL_PARITY_DIFFERENCE,PRETRAIN.DISPARATE_IMPACT]
methoddict={"POSTTRAIN":{"STATISTICAL-PARITY-DIFFERENCE":[POSTTRAIN.STATISTICAL_PARITY_DIFFERENCE],
                                "EQUAL-OPPORTUNITY-DIFFERENCE":[POSTTRAIN.EQUAL_OPPORTUNITY_DIFFERENCE],
                                "AVERAGE-ODDS-DIFFERENCE":[POSTTRAIN.AVERAGE_ODDS_DIFFERENCE], "DISPARATE-IMPACT":[POSTTRAIN.DISPARATE_IMPACT],"ALL":postlist},
                                "PRETRAIN":{"STATISTICAL-PARITY-DIFFERENCE":[PRETRAIN.STATISTICAL_PARITY_DIFFERENCE],
                                          "DISPARATE-IMPACT":[PRETRAIN.DISPARATE_IMPACT],"ALL":prelist}}
