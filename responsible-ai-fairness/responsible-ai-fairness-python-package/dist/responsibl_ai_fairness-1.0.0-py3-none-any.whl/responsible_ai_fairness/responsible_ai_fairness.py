from mappers.mappers import  BiasPretrainAnalyzeRequest, BiasPretrainAnalyzeResponse, BiasPretrainFetchRequest, BiasPretrainFetchResponse ,Facet, BiasResults, metricsEntity
from typing import List
from config.logger import CustomLogger
log = CustomLogger()

import numpy as np
import pandas as pd

from aif360.metrics import BinaryLabelDatasetMetric
from aif360.metrics import ClassificationMetric
from aif360.metrics.utils import compute_boolean_conditioning_vector

from aif360.datasets import StandardDataset

class FairnessService:

    def analyze(payload: BiasPretrainAnalyzeRequest) -> BiasPretrainAnalyzeResponse:
      log.debug(f"payload: {payload}")
      datasetPath = payload.datasetPath
      protectedAttributes=payload.ProtetedAttribute[0]
      CategoricalAttributes=payload.categoricalAttributes
      if CategoricalAttributes==' ':
         CategoricalAttributes= []
      favourableOutcome=payload.favourableOutcome
      label=payload.label
      outputPath = payload.outputPath

      df = pd.read_csv(datasetPath, sep=",")
      label_name = label

      protected_attribute = [protectedAttributes.name]
      
      dataset_orig = StandardDataset(df=df,label_name = label_name,favorable_classes = favourableOutcome,
                                protected_attribute_names=protected_attribute,
                                privileged_classes= [[protectedAttributes.privileged],[protectedAttributes.unprivileged]],
                                instance_weights_name=None,
                                categorical_features= CategoricalAttributes,
                                features_to_keep=[], features_to_drop=[],
                                na_values=[], custom_preprocessing=None,
                                metadata={} 
                              )
    
      privileged_groups = [{f'{protected_attribute[0]}' : 1.0 }]
      unprivileged_groups = [{f'{protected_attribute[0]}' : 0.0 }]

      metric_scaled = BinaryLabelDatasetMetric(dataset_orig, 
                            unprivileged_groups=unprivileged_groups,
                            privileged_groups=privileged_groups)
        
      List_metric_score = []
      obj_metric_sp = metricsEntity(name='STATISTICAL PARITY-DIFFERENCE',
                                    description = 'Computed as the difference of the rate of favorable outcomes received by the unprivileged group to the privileged group.The ideal value of this metric is 0. Fairness for this metric is between -0.1 and 0.1',
                                  value=round(metric_scaled.statistical_parity_difference(),2))
      obj_metric_di = metricsEntity(name='DISPARATE-IMPACT',
                                    description = 'Computed as the ratio of rate of favorable outcome for the unprivileged group to that of the privileged group. The ideal value of this metric is 1.0 A value < 1 implies higher benefit for the privileged group and a value >1 implies a higher benefit for the unprivileged group. Fairness for this metric is between 0.8 and 1.25',
                                  value=round(metric_scaled.disparate_impact(),2))

      List_metric_score.append(obj_metric_sp)
      List_metric_score.append(obj_metric_di)

      log.debug(f"List_metric_score: {List_metric_score}")

      obj_protectAttrib = Facet(name = protectedAttributes.name,
                                          privileged = protectedAttributes.privileged,
                                          unprivileged = protectedAttributes.unprivileged)

      list_bias_results = []
      obj_biasresults = BiasResults(protectedcAttrib = obj_protectAttrib,
                                    metrics = List_metric_score)
      list_bias_results.append(obj_biasresults)

      objbias_pretrainanalyzeResponse = BiasPretrainAnalyzeResponse(biasResults =list_bias_results)

      print(objbias_pretrainanalyzeResponse)

      json_object = objbias_pretrainanalyzeResponse.json()
      print(type(json_object))
      print(json_object)
      
      json_name = outputPath +  "\output.json"
      with open(json_name, "w") as outfile:
        outfile.write(json_object)

      return objbias_pretrainanalyzeResponse
 
