"""
fileName: mappers.py
description: A Pydantic model object for usecase entity model
             which maps the data model to the usecase entity schema
"""

from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional, Union, List

"""
description: Fairness
params: 
""" 

class Facet(BaseModel):
  name:str = Field("sex")
  privileged:str = Field("male")
  unprivileged:str = Field("female")

  class Config:
        orm_mode = True
      
class BiasPretrainAnalyzeRequest(BaseModel):
   toolToBeUsed:str = Field(example="AI-FAIRNESS-360")
   datasetPath: str = Field(example="/mlops-bucket-name/data/use-case01/training-dataset.csv")
   datasetType: str = Field(example="text/csv")
   categoricalAttributes: str = Field(example="Education,City-Category,Job-Type")
   label: str = Field(example="Target")
   favourableOutcome: str = Field(example="1.0")
   ProtetedAttribute:List[Facet]
   outputPath :str = Field(example = "/mlops-bucket-name/data/use-case01/rai-results/")

   class Config:
        orm_mode = True

class metricsEntity(BaseModel):
    name: str = Field(example="STATISTICAL PARITY-DIFFERENCE")
    description: str = Field(example="Computed as the difference of the rate of favorable outcomes received by the unprivileged group to the privileged group.The ideal value of this metric is 0. Fairness for this metric is between -0.1 and 0.1")
    value: float = Field(example=0.25)

    class Config:
        orm_mode = True

class BiasResults (BaseModel):
    protectedcAttrib :Facet
    metrics :List[metricsEntity]
    class Config:
        orm_mode = True

class BiasPretrainAnalyzeResponse(BaseModel):
  biasResults : List[BiasResults]
  class Config:
        orm_mode = True

class BiasPretrainFetchRequest(BaseModel):
    mlModelId:int = Field(example=23)
    class Config:
        orm_mode = True

class BiasPretrainFetchResponse(BaseModel):
     biasResults : List[BiasResults]
     class Config:
        orm_mode = True
    
    
