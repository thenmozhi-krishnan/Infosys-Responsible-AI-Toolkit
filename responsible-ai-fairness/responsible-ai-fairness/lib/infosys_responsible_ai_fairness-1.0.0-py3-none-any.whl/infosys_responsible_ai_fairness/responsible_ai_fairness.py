

from aif360.metrics import BinaryLabelDatasetMetric
from aif360.metrics import ClassificationMetric
from aif360.metrics.utils import compute_boolean_conditioning_vector
from aif360.datasets import StandardDataset
import pandas as pd


privileged_groups=[{}]
unprivileged_groups=[{}]


class AttributeDict(dict):
    __getattr__ = dict.__getitem__
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__

class ProtetedAttribute:
      def __init__(self,name,privileged,unprivileged):
            self.protetedAttribute={"name":name,"privileged": privileged,"unprivileged" :unprivileged}
            self.protetedAttribute=AttributeDict(self.protetedAttribute)

class BiasResults:
      def __init__(self,Biased,protectedcAttrib,metrics):
            self.biasResults={"biasDetected":Biased,"protectedcAttrib":protectedcAttrib,"metrics":metrics}
            self.biasResults=AttributeDict(self.biasResults)

class metricsEntity:
      def __init__(self,name,description,value):
            self.metricsEntity={"name":name,"description":description,"value":value}
            self.metricsEntity=AttributeDict(self.metricsEntity)

      

class DataList:
      def createdataset(df,label_name,favourableOutcome,protectedAttributes,CategoricalAttributes):
            protected_attribute = list(protectedAttributes.name)
            privilegedvar=protectedAttributes.privileged
            print("protected",protected_attribute)
            print("privileged",privilegedvar)
            dataset_orig = StandardDataset(df=df,label_name = label_name,favorable_classes =favourableOutcome,
                                                  protected_attribute_names=protected_attribute,
                                                  privileged_classes= privilegedvar,
                                                  instance_weights_name="",
                                                  categorical_features= CategoricalAttributes,
                                                  features_to_keep=[], features_to_drop=[],
                                                  na_values=[], custom_preprocessing=None,
                                                  metadata={} 
                                                )
            return dataset_orig
      def getDataList(datasetPath,testdata,labelmap,label,protectedAttributes,favourableOutcome,CategoricalAttributes,features,predlabel,biastype)->list:
              protected_attribute = protectedAttributes.name
     
              privileged_groups[0]={}
              unprivileged_groups[0]={}
              for i in range(len(protected_attribute)):
                  privileged_groups[0][protected_attribute[i]]=1.0 
                  unprivileged_groups[0][protected_attribute[i]]= 0.0 
              features.append(label)
              datalist=[]
              if(biastype=="PRETRAIN"):
                        df = pd.read_csv(datasetPath, sep=",",usecols=features)
                        dataset_orig=DataList.createdataset(df,label,favourableOutcome,protectedAttributes,CategoricalAttributes)
                        datalist=[dataset_orig]
              
              if(biastype=="POSTTRAIN" or biastype=="ALL"):
                    features.append(predlabel)
                    df = pd.read_csv(testdata, sep=",",usecols=features)
                    dataset_orig=DataList.createdataset(df,label,favourableOutcome,protectedAttributes,CategoricalAttributes)
                         
                    datalist=[dataset_orig]  
                    dataset_pred=dataset_orig.copy(deepcopy=True)
                    df_pred=df.drop([label],axis=1)
                    favourableOutcome=[labelmap[favourableOutcome[0]]]
                    data_prd=DataList.createdataset(df_pred,predlabel,favourableOutcome,protectedAttributes,CategoricalAttributes)
                    dataset_pred.labels=data_prd.labels
                    datalist.append(dataset_pred)
              return datalist

            
            
class BiasResult:
    def analyzeResult(biastype,methods,protectedAttributes,datalist):
      
        protected_list=[]
        for i in range(len(protectedAttributes.name)):
              
                  obj_protectAttrib = ProtetedAttribute(name = protectedAttributes.name[i],
                                          privileged = protectedAttributes.privileged[i],
                                          unprivileged = protectedAttributes.unprivileged[i])
                  protected_list.append(obj_protectAttrib.protetedAttribute)
      #   print(obj_protectAttrib.protetedAttribute)
                  print(obj_protectAttrib)
        list_metric_results = []
        biased=False
        for i in range(len(methoddict[biastype][methods])):
          List_metric_score= methoddict[biastype][methods][i](datalist)
          if(List_metric_score["value"]!=0.0 or (methods=="DISPARATE-IMPACT" and List_metric_score["value"]!=1.0)):
                biased=True
          list_metric_results.append(List_metric_score)

 
        bias_list=[]
        obj_biasresults = BiasResults(Biased=biased,
                                    protectedcAttrib = protected_list,
                                    metrics = list_metric_results)
        bias_list.append(obj_biasresults.biasResults)

        return(bias_list)
        
        

class PRETRAIN:
   def STATISTICAL_PARITY_DIFFERENCE(datalist):
            metric_scaled = BinaryLabelDatasetMetric(datalist[0], 
                            unprivileged_groups=unprivileged_groups,
                            privileged_groups=privileged_groups)
            score=round(metric_scaled.statistical_parity_difference(),2)
            obj_metric_sp = metricsEntity(name='STATISTICAL PARITY-DIFFERENCE',
                                    description = 'The difference in the rate of favorable outcomes received by unprivileged group to the privileged group. Ideal value for this is 0, which means there is no biasness present. Negative value for this means that the data is biased towards the privileged group and positive values means, it is biased towards the unprivileged group.',
                                  value=score)
            
            
            return obj_metric_sp.metricsEntity
   
   def DISPARATE_IMPACT(datalist):
            metric_scaled = BinaryLabelDatasetMetric(datalist[0], 
                            unprivileged_groups=unprivileged_groups,
                            privileged_groups=privileged_groups) 
            obj_metric_di = metricsEntity(name='DISPARATE-IMPACT',
                                    description = 'Ratio of the rate of favorable outcome for the unprivileged group to the privileged group. Ideal value is 1.',
                                  value=round(metric_scaled.disparate_impact(),2))
            return obj_metric_di.metricsEntity

class POSTTRAIN:
   def STATISTICAL_PARITY_DIFFERENCE(datalist):
            metric_scaled = ClassificationMetric(datalist[0],datalist[1], 
                            unprivileged_groups=unprivileged_groups,
                            privileged_groups=privileged_groups)
            
            obj_metric_sp = metricsEntity(name='STATISTICAL PARITY-DIFFERENCE',
                                    description = 'The difference in the rate of favorable outcomes received by unprivileged group to the privileged group. Ideal value for this is 0, which means there is no biasness present. Negative value for this means that the data is biased towards the privileged group and positive values means, it is biased towards the unprivileged group.',
                                  value=round(metric_scaled.statistical_parity_difference(),2))
            return obj_metric_sp.metricsEntity
   
   def DISPARATE_IMPACT(datalist):
            metric_scaled = ClassificationMetric(datalist[0],datalist[1], 
                            unprivileged_groups=unprivileged_groups,
                            privileged_groups=privileged_groups) 
            obj_metric_di = metricsEntity(name='DISPARATE-IMPACT',
                                    description = 'Ratio of the rate of favorable outcome for the unprivileged group to the privileged group. Ideal value is 1.',
                                  value=round(metric_scaled.disparate_impact(),2))
            return obj_metric_di.metricsEntity

   def EQUAL_OPPORTUNITY_DIFFERENCE(datalist):
            metric_scaled = ClassificationMetric(datalist[0],datalist[1], 
                            unprivileged_groups=unprivileged_groups,
                            privileged_groups=privileged_groups)
            
            obj_metric_eod = metricsEntity(name='EQUAL-OPPORTUNITY-DIFFERENCE',
                                    description = 'Difference of the True Positive Rate of unprivileged group to the privileged group. Ideal value for no bias present is 0.',
                                  value=round(metric_scaled.equal_opportunity_difference(),2))
            return obj_metric_eod.metricsEntity
   
   def AVERAGE_ODDS_DIFFERENCE(datalist):
            metric_scaled = ClassificationMetric(datalist[0],datalist[1], 
                            unprivileged_groups=unprivileged_groups,
                            privileged_groups=privileged_groups) 
                            
            obj_metric_aod = metricsEntity(name='AVERAGE-ODDS-DIFFERENCE',
                                    description = 'The average difference of false positive rate and true positive rate between unprivileged group to the privileged group. Ideal value is 0.',
                                  value=round(metric_scaled.average_odds_difference() ,2))
            return obj_metric_aod.metricsEntity

postlist=[POSTTRAIN.STATISTICAL_PARITY_DIFFERENCE,POSTTRAIN.EQUAL_OPPORTUNITY_DIFFERENCE,POSTTRAIN.AVERAGE_ODDS_DIFFERENCE,POSTTRAIN.DISPARATE_IMPACT]      
prelist=[PRETRAIN.STATISTICAL_PARITY_DIFFERENCE,PRETRAIN.DISPARATE_IMPACT]
methoddict={"POSTTRAIN":{"STATISTICAL-PARITY-DIFFERENCE":[POSTTRAIN.STATISTICAL_PARITY_DIFFERENCE],
                                "EQUAL-OPPORTUNITY-DIFFERENCE":[POSTTRAIN.EQUAL_OPPORTUNITY_DIFFERENCE],
                                "AVERAGE-ODDS-DIFFERENCE":[POSTTRAIN.AVERAGE_ODDS_DIFFERENCE], "DISPARATE-IMPACT":[POSTTRAIN.DISPARATE_IMPACT],"ALL":postlist},
                                "PRETRAIN":{"STATISTICAL-PARITY-DIFFERENCE":[PRETRAIN.STATISTICAL_PARITY_DIFFERENCE],
                                          "DISPARATE-IMPACT":[PRETRAIN.DISPARATE_IMPACT],"ALL":prelist}}


# Statistical Parity Difference: The difference in the rate of favorable outcomes received by unprivileged group to the privileged group. Ideal value for this is 0, which means there is no biasness present. Negative value for this means that the data is biased towards the privileged group and positive values means, it is biased towards the unprivileged group.
# Disparate Impact: Ratio of the rate of favorable outcome for the unprivileged group to the privileged group. Ideal value is 1.
# Equal opportunity difference: Difference of the True Positive Rate of unprivileged group to the privileged group. Ideal value for no bias present is 0.
# Average odds difference: The average difference of false positive rate and true positive rate between unprivileged group to the privileged group. Ideal value is 0.