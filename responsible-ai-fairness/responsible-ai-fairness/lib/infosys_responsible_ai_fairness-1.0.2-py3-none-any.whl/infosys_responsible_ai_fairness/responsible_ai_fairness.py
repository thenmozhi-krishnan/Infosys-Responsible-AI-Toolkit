from aif360.metrics import BinaryLabelDatasetMetric
from aif360.metrics import ClassificationMetric
from aif360.metrics.utils import compute_boolean_conditioning_vector
from aif360.datasets import StandardDataset
from aif360.algorithms.preprocessing.reweighing import Reweighing
from aif360.algorithms.preprocessing.optim_preproc import OptimPreproc
from aif360.algorithms.preprocessing.optim_preproc_helpers.distortion_functions import *
from aif360.algorithms.preprocessing.optim_preproc_helpers.opt_tools import OptTools
from aif360.algorithms.preprocessing.lfr import LFR
from aif360.algorithms.preprocessing import DisparateImpactRemover
from tqdm import tqdm

import pandas as pd
import numpy as np

privileged_groups = [{}]
unprivileged_groups = [{}]
datalist = {}


class AttributeDict(dict):
    __getattr__ = dict.__getitem__
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__


class ProtetedAttribute:
    def __init__(self, name, privileged, unprivileged):
        self.protetedAttribute = {"name": name, "privileged": privileged, "unprivileged": unprivileged}
        self.protetedAttribute = AttributeDict(self.protetedAttribute)


class BiasResults:
    def __init__(self, Biased, protectedcAttrib, metrics):
        self.biasResults = {"biasDetected": Biased, "protectedAttribute": protectedcAttrib, "metrics": metrics}
        self.biasResults = AttributeDict(self.biasResults)


class metricsEntity:
    def __init__(self, name, description, value):
        self.metricsEntity = {"name": name, "description": description, "value": value}
        self.metricsEntity = AttributeDict(self.metricsEntity)


class MitigationResults:
    def __init__(self, mitigation_type, mitigation_technique, original_score_value_list, original_bias_detected, score_value_list, bias_detected):
        self.mitigationResults = {"mitigationType": mitigation_type, "mitigationTechnique": mitigation_technique,
                                  "metricsBeforeMitigation": original_score_value_list, "biasDetectedOriginally" : original_bias_detected,
                                  "metricsAfterMitigation": score_value_list,  "biasDetectedAfterMitigation": bias_detected}
        self.mitigationResults = AttributeDict(self.mitigationResults)


class DataList:
    def createdataset(self, df, label_name, favourableOutcome, protectedAttributes, CategoricalAttributes):
        protected_attribute = list(protectedAttributes.name)
        privilegedvar = protectedAttributes.privileged
        dataset_orig = StandardDataset(df=df, label_name=label_name, favorable_classes=favourableOutcome,
                                       protected_attribute_names=protected_attribute,
                                       privileged_classes=privilegedvar,
                                       instance_weights_name="",
                                       categorical_features=CategoricalAttributes,
                                       features_to_keep=[], features_to_drop=[],
                                       na_values=[], custom_preprocessing=None,
                                       metadata={}
                                       )
        return dataset_orig

    def getDataList(self, datasetPath, testdata, labelmap, label, protectedAttributes, favourableOutcome,
                    CategoricalAttributes, features, predlabel, biastype) -> list:
        protected_attribute = protectedAttributes.name
        privileged_groups[0] = {}
        unprivileged_groups[0] = {}
        for i in range(len(protected_attribute)):
            privileged_groups[0][protected_attribute[i]] = 1.0
            unprivileged_groups[0][protected_attribute[i]] = 0.0
        features.append(label)
        ds = DataList()
        if (biastype == "PRETRAIN"):
            df = pd.read_csv(datasetPath, sep=",", usecols=features)
            dataset_orig = ds.createdataset(df, label, favourableOutcome, protectedAttributes,
                                                  CategoricalAttributes)
            datalist['dataset_original'] = dataset_orig

        if (biastype == "POSTTRAIN" or biastype == "ALL"):
            features.append(predlabel)
            df = pd.read_csv(testdata, sep=",", usecols=features)

            dataset_orig = ds.createdataset(df, label, favourableOutcome, protectedAttributes,
                                                  CategoricalAttributes)

            datalist['dataset_original'] = dataset_orig
            dataset_pred = dataset_orig.copy(deepcopy=True)
            df_pred = df.drop([label], axis=1)
            favourableOutcome = [labelmap[favourableOutcome[0]]]
            data_prd = ds.createdataset(df_pred, predlabel, favourableOutcome, protectedAttributes,
                                              CategoricalAttributes)
            dataset_pred.labels = data_prd.labels
            datalist['dataset_prediction'] = dataset_pred
        return datalist


class BiasResult:
    def analyzeResult(self, biastype, methods, protectedAttributes, datalist):
        protected_list = []
        for i in range(len(protectedAttributes.name)):
            obj_protectAttrib = ProtetedAttribute(name=protectedAttributes.name[i],
                                                  privileged=protectedAttributes.privileged[i],
                                                  unprivileged=protectedAttributes.unprivileged[i])
            protected_list.append(obj_protectAttrib.protetedAttribute)
        list_metric_results = []
        biased = False
        biased_list = []
        for i in range(len(methoddict[biastype][methods])):
            List_metric_score = methoddict[biastype][methods][i](datalist)
            # if (List_metric_score["value"] != 0.0) and (
            #         methods == "DISPARATE-IMPACT" and List_metric_score["value"] != 1.0)):
            #     biased = True
            if methods == "DISPARATE-IMPACT":
                if List_metric_score["value"] != 1.0:
                    biased = True
                else:
                    biased = False
            else:
                if List_metric_score["value"] != 0.0:
                    biased = True
                else:
                    biased = False
            biased_list.append(biased)
            list_metric_results.append(List_metric_score)

        if True in biased_list:
            biased = True
        else:
            biased = False

        bias_list = []
        obj_biasresults = BiasResults(Biased=biased,
                                      protectedcAttrib=protected_list,
                                      metrics=list_metric_results)
        bias_list.append(obj_biasresults.biasResults)

        return (bias_list)


class MitigationResult:
    def mitigateResult(self, mitigationType, mitigationTechnique, datalist):
        mitigation_results_list = []
        for i in range(len(mitigationTechniqueDict[mitigationType][mitigationTechnique])):
            transformation_score_dictOffDict = mitigationTechniqueDict[mitigationType][mitigationTechnique][i](datalist)
            pre_mitigation = transformation_score_dictOffDict['metricsBeforeMitigation']
            post_mitigation = transformation_score_dictOffDict['metricsAfterMitigation']
            biased_after_mitigation = post_mitigation['Bias Detected']
            bias_before_mitigation = pre_mitigation['Bias Detected']
            original_metrics = pre_mitigation['Metrics']
            metrics_value = post_mitigation['Metrics']

            obj_mitigation_results = MitigationResults(mitigation_type=mitigationType,
                                                       mitigation_technique=mitigationTechnique,
                                                       original_score_value_list=original_metrics, original_bias_detected =bias_before_mitigation,
                                                       score_value_list=metrics_value, bias_detected =biased_after_mitigation)
            mitigation_results_list.append(obj_mitigation_results.mitigationResults)

        return mitigation_results_list


class PRETRAIN:
    def STATISTICAL_PARITY_DIFFERENCE(datalist):
        metric_scaled = BinaryLabelDatasetMetric(datalist['dataset_original'],
                                                 unprivileged_groups=unprivileged_groups,
                                                 privileged_groups=privileged_groups)
        score = round(metric_scaled.statistical_parity_difference(), 2)
        obj_metric_sp = metricsEntity(name='STATISTICAL PARITY-DIFFERENCE',
                                      description='The difference in the rate of favorable outcomes received by unprivileged group to the privileged group. Ideal value for this is 0, which means there is no biasness present. Negative value for this means that the data is biased towards the privileged group and positive values means, it is biased towards the unprivileged group.',
                                      value=score)

        return obj_metric_sp.metricsEntity

    def DISPARATE_IMPACT(datalist):
        metric_scaled = BinaryLabelDatasetMetric(datalist['dataset_original'],
                                                 unprivileged_groups=unprivileged_groups,
                                                 privileged_groups=privileged_groups)
        score = round(metric_scaled.disparate_impact(), 2)
        obj_metric_di = metricsEntity(name='DISPARATE-IMPACT',
                                      description='Ratio of the rate of favorable outcome for the unprivileged group to the privileged group. Ideal value is 1.',
                                      value=score)
        return obj_metric_di.metricsEntity


class PREPROCESSING_MITIGATION:
    def metric_score_result(pre_mitigation_score, post_mitigation_score):
        metric_scores = {'metricsBeforeMitigation': pre_mitigation_score,
                         'metricsAfterMitigation': post_mitigation_score}
        return metric_scores

    def metric_score_entity(transformed_dataset, fairness_metric):
        biased_metric = {}
        original_metric_score_list =[]
        metric_score_list = []
        biasness_list = []
        metric_scaled = BinaryLabelDatasetMetric(transformed_dataset, unprivileged_groups=unprivileged_groups,
                                                 privileged_groups=privileged_groups)

        for i in range(len(fairness_metric)):
            metric_entity = {}
            biased = False

            if fairness_metric[i] == 'statistical_parity_difference':
                score = round(metric_scaled.statistical_parity_difference(), 2)
                metric_entity['name'] = 'STATISTICAL PARITY-DIFFERENCE'
                metric_entity['description'] = 'The difference in the rate of favorable outcomes received by ' \
                                               'unprivileged group to the privileged group. Ideal value for this is ' \
                                               '0, which means there is no biasness present. Negative value for this ' \
                                               'means that the data is biased towards the privileged group and ' \
                                               'positive values means, it is biased towards the unprivileged group.'
                metric_entity['value'] = score
                if score > 0.0 or score < 0.0:
                    biased = True
                else:
                    biased = False
                metric_score_list.append(metric_entity)
                biasness_list.append(biased)

            elif fairness_metric[i] == 'disparate_impact':
                score = round(metric_scaled.disparate_impact(), 2)
                metric_entity['name'] = 'DISPARATE-IMPACT'
                metric_entity['description'] = 'Ratio of the rate of favorable outcome for the unprivileged group to ' \
                                               'the ' \
                                               'privileged group. Ideal value is 1.'
                metric_entity['value'] = score
                if score > 1.0 or score < 1.0:
                    biased = True
                else:
                    biased = False
                metric_score_list.append(metric_entity)
                biasness_list.append(biased)

        if True in biasness_list:
            biased_detected = True
        else:
            biased_detected = False

        biased_metric['Bias Detected'] = biased_detected
        biased_metric['Metrics'] = metric_score_list

        return biased_metric

    def REWEIGHING(datalist):
        datalst = datalist['dataset_original']
        reweighted = Reweighing(unprivileged_groups=unprivileged_groups,
                                privileged_groups=privileged_groups)

        reweighted = reweighted.fit(datalst)
        transformed_trained_dataset = reweighted.transform(datalst)
        fairness_metric_method_list = ['statistical_parity_difference', 'disparate_impact']
        original_metric_score_dict = PREPROCESSING_MITIGATION.metric_score_entity(datalst, fairness_metric_method_list)
        metric_score_dict = PREPROCESSING_MITIGATION.metric_score_entity(transformed_trained_dataset, fairness_metric_method_list)

        metric_dict = PREPROCESSING_MITIGATION.metric_score_result(original_metric_score_dict,metric_score_dict)
        return metric_dict

    def LFR(datalist):
        datalst = datalist['dataset_original']
        max_iterations = 5
        max_function_eval = 5

        lfr = LFR(unprivileged_groups=unprivileged_groups,
                  privileged_groups=privileged_groups)

        lfr = lfr.fit(datalst, maxiter=max_iterations, maxfun=max_function_eval)
        transformed_dataset = lfr.transform(datalst)

        fairness_metric_method_list = ['statistical_parity_difference']
        metric_score_dict = PREPROCESSING_MITIGATION.metric_score_entity(transformed_dataset,
                                                                         fairness_metric_method_list)
        original_metric_score_dict = PREPROCESSING_MITIGATION.metric_score_entity(datalst, fairness_metric_method_list)
        metric_dict = PREPROCESSING_MITIGATION.metric_score_result(original_metric_score_dict, metric_score_dict)
        return metric_dict

    def DISPARATE_IMPACT_REMOVER(datalist):
        datalst = datalist['dataset_original']
        metric_score_list = []
        DIs = []
        for level in tqdm(np.linspace(0., 1., 11)):
            di = DisparateImpactRemover(repair_level=level)
            transformed_dataset = di.fit_transform(datalst)
            fairness_metric_method_list = ['disparate_impact']
            metric_score_dict = PREPROCESSING_MITIGATION.metric_score_entity(transformed_dataset,
                                                                             fairness_metric_method_list)
            original_metric_score_dict = PREPROCESSING_MITIGATION.metric_score_entity(datalst,
                                                                                      fairness_metric_method_list)
            metric_dict = PREPROCESSING_MITIGATION.metric_score_result(original_metric_score_dict, metric_score_dict)
            DIs.append(metric_dict)

        return DIs[0]

    def OPTIM_PREPROCESSOR(datalist):
        optimizer = OptTools
        datalst = datalist['dataset_original']
        optimization_options = {
            "distortion_fun": get_distortion_adult,
            "epsilon": 0.05,
            "clist": [0.99, 1.99, 2.99],
            "dlist": [.1, 0.05, 0]
        }
        OP = OptimPreproc(optimizer, optimization_options)
        OP = OP.fit(datalst)
        transformed_dataset = OP.transform(datalst, transform_Y=True)
        transformed_dataset = datalst.align_datasets(transformed_dataset)
        fairness_metric_method_list = ['statistical_parity_difference', 'disparate_impact']
        metric_score_dict = PREPROCESSING_MITIGATION.metric_score_entity(transformed_dataset,
                                                                         fairness_metric_method_list)
        original_metric_score_dict = PREPROCESSING_MITIGATION.metric_score_entity(datalst, fairness_metric_method_list)
        metric_dict = PREPROCESSING_MITIGATION.metric_score_result(original_metric_score_dict, metric_score_dict)
        return metric_dict


class POSTTRAIN:
    def STATISTICAL_PARITY_DIFFERENCE(datalist):
        metric_scaled = ClassificationMetric(datalist['dataset_original'], datalist['dataset_prediction'],
                                             unprivileged_groups=unprivileged_groups,
                                             privileged_groups=privileged_groups)

        obj_metric_sp = metricsEntity(name='STATISTICAL PARITY-DIFFERENCE',
                                      description='The difference in the rate of favorable outcomes received by unprivileged group to the privileged group. Ideal value for this is 0, which means there is no biasness present. Negative value for this means that the data is biased towards the privileged group and positive values means, it is biased towards the unprivileged group.',
                                      value=round(metric_scaled.statistical_parity_difference(), 2))
        return obj_metric_sp.metricsEntity

    def DISPARATE_IMPACT(datalist):
        metric_scaled = ClassificationMetric(datalist['dataset_original'], datalist['dataset_prediction'],
                                             unprivileged_groups=unprivileged_groups,
                                             privileged_groups=privileged_groups)
        obj_metric_di = metricsEntity(name='DISPARATE-IMPACT',
                                      description='Ratio of the rate of favorable outcome for the unprivileged group to the privileged group. Ideal value is 1.',
                                      value=round(metric_scaled.disparate_impact(), 2))
        return obj_metric_di.metricsEntity

    def EQUAL_OPPORTUNITY_DIFFERENCE(datalist):
        metric_scaled = ClassificationMetric(datalist['dataset_original'], datalist['dataset_prediction'],
                                             unprivileged_groups=unprivileged_groups,
                                             privileged_groups=privileged_groups)

        obj_metric_eod = metricsEntity(name='EQUAL-OPPORTUNITY-DIFFERENCE',
                                       description='Difference of the True Positive Rate of unprivileged group to the privileged group. Ideal value for no bias present is 0.',
                                       value=round(metric_scaled.equal_opportunity_difference(), 2))
        return obj_metric_eod.metricsEntity

    def AVERAGE_ODDS_DIFFERENCE(datalist):
        metric_scaled = ClassificationMetric(datalist['dataset_original'], datalist['dataset_prediction'],
                                             unprivileged_groups=unprivileged_groups,
                                             privileged_groups=privileged_groups)

        obj_metric_aod = metricsEntity(name='AVERAGE-ODDS-DIFFERENCE',
                                       description='The average difference of false positive rate and true positive rate between unprivileged group to the privileged group. Ideal value is 0.',
                                       value=round(metric_scaled.average_odds_difference(), 2))
        return obj_metric_aod.metricsEntity


postlist = [POSTTRAIN.STATISTICAL_PARITY_DIFFERENCE, POSTTRAIN.EQUAL_OPPORTUNITY_DIFFERENCE,
            POSTTRAIN.AVERAGE_ODDS_DIFFERENCE, POSTTRAIN.DISPARATE_IMPACT]
prelist = [PRETRAIN.STATISTICAL_PARITY_DIFFERENCE, PRETRAIN.DISPARATE_IMPACT]
methoddict = {"POSTTRAIN": {"STATISTICAL-PARITY-DIFFERENCE": [POSTTRAIN.STATISTICAL_PARITY_DIFFERENCE],
                            "EQUAL-OPPORTUNITY-DIFFERENCE": [POSTTRAIN.EQUAL_OPPORTUNITY_DIFFERENCE],
                            "AVERAGE-ODDS-DIFFERENCE": [POSTTRAIN.AVERAGE_ODDS_DIFFERENCE],
                            "DISPARATE-IMPACT": [POSTTRAIN.DISPARATE_IMPACT], "ALL": postlist},
              "PRETRAIN": {"STATISTICAL-PARITY-DIFFERENCE": [PRETRAIN.STATISTICAL_PARITY_DIFFERENCE],
                           "DISPARATE-IMPACT": [PRETRAIN.DISPARATE_IMPACT], "ALL": prelist}}

preprocessingMitigationTechniqueList = [PREPROCESSING_MITIGATION.REWEIGHING, PREPROCESSING_MITIGATION.LFR,
                                        PREPROCESSING_MITIGATION.DISPARATE_IMPACT_REMOVER,
                                        PREPROCESSING_MITIGATION.OPTIM_PREPROCESSOR]
mitigationTechniqueDict = {
    "PREPROCESSING": {
        "REWEIGHING": [PREPROCESSING_MITIGATION.REWEIGHING],
        "LFR": [PREPROCESSING_MITIGATION.LFR],
        "DISPARATE_IMPACT_REMOVER": [PREPROCESSING_MITIGATION.DISPARATE_IMPACT_REMOVER],
        "OPTIM_PREPROCESSOR": [PREPROCESSING_MITIGATION.OPTIM_PREPROCESSOR]
        # "ALL": preprocessingMitigationTechniqueList
    }
}

# Statistical Parity Difference: The difference in the rate of favorable outcomes received by unprivileged group to the privileged group. Ideal value for this is 0, which means there is no biasness present. Negative value for this means that the data is biased towards the privileged group and positive values means, it is biased towards the unprivileged group.
# Disparate Impact: Ratio of the rate of favorable outcome for the unprivileged group to the privileged group. Ideal value is 1.
# Equal opportunity difference: Difference of the True Positive Rate of unprivileged group to the privileged group. Ideal value for no bias present is 0.
# Average odds difference: The average difference of false positive rate and true positive rate between unprivileged group to the privileged group. Ideal value is 0.
