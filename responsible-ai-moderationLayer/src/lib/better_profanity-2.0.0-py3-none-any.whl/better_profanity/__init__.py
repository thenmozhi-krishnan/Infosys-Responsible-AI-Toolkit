# -*- coding: utf-8 -*-

from .better_profanity import Profanity

__all__ = ["name", "__version__", "profanity"]

name = "better_profanity"
__version__ = "0.7.0"

profanity = Profanity()
