#  # src/privacy/util/auth/auth_jwt.py

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer
import os
import jwt
from dotenv import load_dotenv
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import jwt, ExpiredSignatureError, JWTError 
import logging
import traceback

load_dotenv()
log = logging.getLogger(__name__)
security = HTTPBearer()
secret_key = os.environ.get("SECRET_KEY")

def authenticate_jwt(credentials: HTTPAuthorizationCredentials = Depends(security)):
    token = credentials.credentials
    try:
        payload = jwt.decode(token, secret_key, algorithms=["HS256"],options={"verify_signature": False, "verify_aud": False})
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token expired",
            headers={"WWW-Authenticate": "Bearer"},
        )
    except jwt.JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    except Exception as e:
        log.error(f"Unexpected error: {e}")
        log.error(str(traceback.extract_tb(e.__traceback__)[0].lineno))
        raise HTTPException(status_code=500, detail="Unexpected error")

    return payload

def get_auth_jwt():
    return authenticate_jwt