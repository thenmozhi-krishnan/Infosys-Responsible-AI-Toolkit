#       # src/privacy/util/auth/auth_none.py

from fastapi import Depends

def authenticate_none():
    return True

def get_auth_none():
    return authenticate_none