
import random
import string
from faker import Faker
from xeger import Xeger
x = Xeger()
faker = Faker()

class FakeData:

    def PERSON():
        return faker.name()
    
    def EMAIL_ADDRESS():
        return faker.email()
    
    def US_SSN():
        return faker.ssn()
    
    def ADDRESS():
        return faker.address()
    
    def DATE_TIME():
        return faker.date()
    
    def LOCATION():
        return faker.city()
    

    def CREDIT_CARD():
        return faker.credit_card_number()
    
    def CRYPTO():
        return faker.cryptocurrency_name()
    
    def DATE():
        return faker.date()
    
    def IP_ADDRESS():
        return faker.ipv4()
    
    def PHONE_NUMBER():
        return faker.phone_number()
    
    # def AADHAR_NUMBER():
    #     fake=Faker()
    #     aadhaar_number = fake.random_int(min=100000000000, max=999999999999)  # Generate a 12-digit random number
    #     aadhaar_number = str(aadhaar_number)  # Convert the number to a string
    #     aadhaar_number_with_space = ' '.join(aadhaar_number[i:i+4] for i in range(0, len(aadhaar_number), 4))
    #     return aadhaar_number_with_space


    # def PAN_Number():
    #     p="[A-Z]{5}[0-9]{4}[A-Z]{1}"
    #     t=x.xeger(p)
    #     print(t)
        
    #     return t
    
    def IBAN_CODE():
        return faker.iban()
    
    def PASSPORT():
        # print("faker.passport_number()",faker.passport_number())
        return faker.passport_number()

    def DataList(data,text):
        random_data=random.choice([item for item in entValue if str(item).lower() != text.lower()])
        return random_data

    

# class FakeDataList:

#     def 