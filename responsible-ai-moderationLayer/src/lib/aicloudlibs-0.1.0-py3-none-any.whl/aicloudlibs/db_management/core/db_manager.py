from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from aicloudlibs.db_management.config import config
from aicloudlibs.db_management.config.logger import CustomLogger
from aicloudlibs.utils.global_exception import DbConnectionError,DatabaseError
from aicloudlibs.db_management.exception.exceptions import AicloudDBException
import os,sys

log=CustomLogger()

BASE_DIR=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
db_cfg_path=os.path.join(BASE_DIR,'database.ini')
db_param=config.readConfig('postgresql',db_cfg_path)




SQLALCHEMY_DATABASE_URL = db_param['database_uri']
log.info("connecting to database: "+SQLALCHEMY_DATABASE_URL)

try:
        engine = create_engine(SQLALCHEMY_DATABASE_URL)   

        SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

        Base = declarative_base()
except Exception as e:
     if(type(e).__name__ == "InterfaceError"):
        raise DbConnectionError(db_param['DATABASE_URI'])
     if(type(e).__name__ == "DatabaseError"):
        raise DatabaseError(db_param['DATABASE_URI'])
     else:
        raise AicloudDBException(str(e))
       
