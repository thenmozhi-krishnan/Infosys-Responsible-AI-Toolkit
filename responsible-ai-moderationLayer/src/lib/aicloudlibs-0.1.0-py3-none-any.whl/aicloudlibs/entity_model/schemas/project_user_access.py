from sqlalchemy import Boolean, Column, ForeignKey, Integer, String,JSON,DateTime
from sqlalchemy.orm import relationship
from aicloudlibs.db_management.core.db_manager import Base
from aicloudlibs.entity_model.constants import constants
from aicloudlibs.entity_model.schemas.usecase import usecase
from aicloudlibs.entity_model.schemas.project import project



class project_user_access(Base):
    __tablename__ = constants.PROJECT_USER_ACCESS_TABLE

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)
    description = Column(String)
    create_pipeline = Column(bool)
    execute_pipeline = Column(bool)
    workspace_admin = Column(bool)
    deploy_model = Column(bool)
    view= Column(bool)
    userEmail = Column(String)
    usecase_id = Column(Integer, ForeignKey("usecase.id"))
    project_id = Column(Integer, ForeignKey("project.id"))
    is_deleted = Column(Boolean, default=False)
    createdBy= Column(String)
    updatedBy = Column(String)
    created_on = Column(DateTime)
    modified_on = Column(DateTime)
    