from sqlalchemy import Boolean, Column, ForeignKey, Integer, String,JSON,DateTime
from sqlalchemy.orm import relationship

from aicloudlibs.db_management.core.db_manager import Base
from aicloudlibs.entity_model.constants import constants
from aicloudlibs.entity_model.schemas.usecase import usecase


class project(Base):
    __tablename__ = constants.PROJECT_TABLE

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)
    description = Column(String)
    usecase_id = Column(Integer, ForeignKey("usecase.id"))
    stage= Column(String)
    is_deleted = Column(Boolean, default=False)
    createdBy= Column(String)
    updatedBy = Column(String)
    created_on = Column(DateTime)
    modified_on = Column(DateTime)