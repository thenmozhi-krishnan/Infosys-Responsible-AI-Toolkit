from sqlalchemy import Boolean, Column, ForeignKey, Integer, String,JSON,DateTime
from sqlalchemy.orm import relationship

from aicloudlibs.db_management.core.db_manager import Base
from aicloudlibs.entity_model.constants import constants



class usecase(Base):
    __tablename__ = constants.USECASE_TABLE

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)
    description = Column(String)
    stage = Column(String)
    is_deleted = Column(Boolean, default=False)
    createdby= Column(String)
    updatedby = Column(String)
    created_on = Column(DateTime)
    modified_on = Column(DateTime)