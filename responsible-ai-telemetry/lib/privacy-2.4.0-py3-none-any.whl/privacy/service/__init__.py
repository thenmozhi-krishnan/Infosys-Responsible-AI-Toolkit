import contextvars
from presidio_analyzer import Pattern, PatternRecognizer, AnalyzerEngine, RecognizerRegistry, predefined_recognizers
from presidio_anonymizer import AnonymizerEngine
from privacy.config.logger import CustomLogger
from presidio_image_redactor import ImageRedactorEngine, ImageAnalyzerEngine, ImagePiiVerifyEngine       
from presidio_image_redactor import DicomImageRedactorEngine

log = CustomLogger()


from presidio_analyzer.nlp_engine import SpacyNlpEngine
import spacy
from privacy.util.lemma_context_aware_enhancer1 import LemmaContextAwareEnhancer


# print("===========init==========")
error_dict={}
admin_par={}
session_dict = contextvars.ContextVar('session_dict', default={})

# Example usage:
def update_session_dict(key, value):
    session_dict.get()[key] = value

def get_session_dict():
    return session_dict.get()

class AttributeDict(dict):
    __getattr__ = dict.__getitem__
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__
    
registry = RecognizerRegistry()
anonymizer = AnonymizerEngine()


# Create an instance of LemmaContextAwareEnhancer
lemma_context_aware_enhancer = LemmaContextAwareEnhancer()

# analyzer = AnalyzerEngine(registry=registry,nlp_engine=loaded_nlp_engine)
"""Deafult NLP , Less Accuracy less latency"""
analyzer_l = AnalyzerEngine(registry=registry,context_aware_enhancer=lemma_context_aware_enhancer)




"""En_core_web_trf NLP , slightly better Accuracy little High latency"""
class LoadedSpacyNlpEngine(SpacyNlpEngine):
    def __init__(self, loaded_spacy_model):
        super().__init__()
        self.nlp = {"en": loaded_spacy_model}

registry.load_predefined_recognizers()

def selectNlp(nlpName):     
    if nlpName == "basic":
        print("basic")
        return analyzer_l
    else:
        return analyzer_l